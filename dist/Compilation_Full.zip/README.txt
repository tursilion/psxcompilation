This is my final compilation of all my public Playstation work.

Burning
-------
Compilation_Full is the main download.
It consists of an ISO file created with Easy CD Pro, and the
audio tracks saved as MP3. Using Easy CD Pro, you can create
a mixed mode CD using the ISO image and the audio tracks.
If you use another package to record this, be aware that the
ISO is XA-Mode2, with 2352 byte sectors. Your CD software
may or may not require you to convert the MP3s to WAV (my
version of Easy CD Pro does.)

Here's what we've got:

Boot Menu
---------
A slightly modified version of the 'Simple Menu System' 
by Richard 'TNomad' Perrin [nomad@anime.demon.co.uk]
Starfield code derived from Jeff Lawton (aka Zark Wizard)'s Starfield lib

TetraDemo
---------
My first Playstation release - this is actually the second version,
as the first used the Yaroze MIDI player and played some rather
painful MIDIs for background. This version plays CD audio. Feel
free to change out the disc while playing this version to get
different background music! Artwork by Foxxfire - all fantasy
pinups (but clean, unlike the XXX version). I believe there are
only 8 pictures in this one. One font is the standard VGA font
off my video card, the other is from an old Amiga CD I have. The
actual Tetris code is from a text-mode tetris for the PC I wrote
way back when..
Use R1 to change the music, and R2 to start with a rotating 
playfield and maximum handicap. Other keys are listed onscreen.

Takatron
--------
This was started before TetraDemo, but abandoned, then restarted.
It's a port of my PC game of the same name. I sort of wish I'd
waited till I knew the PSX better before doing this, as I have
a much better idea now how to do things like the color cycling
and plasma effects, (not to mention fitting in all the gfx), 
but oh well. Takatron supports the dual analog sticks, as well. 
It also creates a save file for high scores if there is a 
memory card with a free block - but be warned that it doesn't 
write the file according to spec and therefore the file doesn't 
show an icon. It won't hurt anything, though, so don't worry too much.
The main sprites, except the Rhino, Kitu (literally, 'Thing'), and electrodes,
are all ripped from the Genesis version of The Lion King, using Genecyst.
(I drew the other crap). The blue mecha-jaguar boss and Dr Wily are
ripped from Megaman 2 using Nesticle (if I remember right), and
the final Scar boss was drawn by David Sauve and is used with
permission! ;) Holding combinations of 3 of the shoulder buttons
while pressing 'X' during the scroll text will activate various
cheat modes. The mode you get is displayed briefly at the bottom
of the screen. (There are one or two modes which are combinations of
only two shoulder buttons, but if you hold an invalid combination
and press X, the game starts instead.) I can't remember what's what,
you can work that out yourself. ;) Takatron has a total of seven
different ending texts. ;)

CrapDemo
--------
I'd always checked out every new PSX demo I could get my paws on
when starting out, and when seeing the fourth (I think) release
from an anonymous group (*COUGH*BP*COUGH*) was a static picture
and a scroll text, I knew it was time for me to get in on the whole
intro thing. Thus... CrapDemo was born. CrapDemo shows the Moving
Target logo, while a font derived from Microsoft's Comic Sans Serif
crawls along the bottom. But, I couldn't live with that, and it
does do a few things once you give it enough time. ;)

Sand Demo
---------
This was an idea that came to mind once - what would it look like
to do a particle demo with images forming and breaking up? It
didn't quite reach my expectations for the number of particles,
but it's still pretty unusual. If you have Caetla, run it through
that, and the debug text introduces every picture as it forms.
The pics are all very old things from my HD, run through a crude
filter to reduce them to the appropriate number of particles. ;)

Captain C Demo
--------------
I kind of wish I'd finished this, and I may restart it on another
system some day. Captain Communism was intended to be a Mega Man
clone, using my brother's superhero character. Foxxfire did the
artwork that is in the game, except for the title page which
I rendered and pasted onto a JPG. ;) However, he discovered he
hates drawing lo-res art, and the project was then abandoned.
Captain C is owned by Steve Brent (Vidi). The voice that you
hear in the game is done by someone who *was* a friend at the
time, but we don't speak often these days. He didn't really want
his name on it, anyway. ;) Press SELECT+START to advance through
the different levels. R1 changes weapons. The other keys can
be changed in the options menu. There are no enemies, and only 
one maze is done.

Damned Demo
-----------
This was the first time I did a project for someone else, 'WPW's
Rocko asked me to do a demo for them. I finally just wrote
this, cause I wanted to try some old effects out. The name
reflects my frustration of the time. ;) But I got 
to try some things I'd never done before, and I was mostly 
pleased - there are some annoying bits. There are three effects - 
3D stars (sorta), balls with light source, and fire, of course. :)

Greets
------
Just displays some greets in the comment block. You can't actually
run this.



